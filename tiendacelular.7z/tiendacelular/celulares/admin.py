from django.contrib import admin

# Register your models here.
from models import celulares

admin.site.register(celulares)
